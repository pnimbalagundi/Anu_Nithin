package api.utilities;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordEncryptor {
    private static final int SALT_LENGTH = 16; // Salt length in bytes
    private static final int ITERATIONS = 100000; // Number of PBKDF2 iterations
    private static final int KEY_LENGTH = 256; // Key length in bits
    private static final String ALGORITHM = "PBKDF2WithHmacSHA1";
    private static final String CIPHER_ALGORITHM = "AES/ECB/PKCS5Padding";

    public static String encryptPassword(String password) throws Exception {
        // Generate a random salt
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);

        // Create key specification using PBKDF2
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH);
        SecretKeyFactory skf = SecretKeyFactory.getInstance(ALGORITHM);
        byte[] key = skf.generateSecret(spec).getEncoded();

        // Create AES key
        SecretKeySpec secretKey = new SecretKeySpec(key, "AES");

        // Initialize Cipher for encryption
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKey);

        // Encrypt the password
        byte[] encrypted = cipher.doFinal(password.getBytes("UTF-8"));

        // Combine salt and encrypted password
        byte[] combined = new byte[salt.length + encrypted.length];
        System.arraycopy(salt, 0, combined, 0, salt.length);
        System.arraycopy(encrypted, 0, combined, salt.length, encrypted.length);

        // Encode to Base64
        return Base64.getEncoder().encodeToString(combined);
    }

    public static void main(String[] args) {
        try {
            String password = "P@$$w0rd";
            String encryptedPassword = encryptPassword(password);
            System.out.println("Encrypted Password: " + encryptedPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}