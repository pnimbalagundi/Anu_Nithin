package api.utilities;

import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtils {

    // Parameters (make them constants or configurable if needed)
    private static final int IV_SIZE = 16; // 128 bits
    private static final int KEY_SIZE = 32; // 256 bits
    private static final int SALT_SIZE = 32; // 256 bits
    private static final int ITERATIONS = 1000;
    private static final String KEY_DERIVATION_ALGORITHM = "PBKDF2WithHmacSHA1";
    private static final String KEY_SPEC_ALGORITHM = "AES";
    private static final String CIPHER_TRANSFORMATION = "AES/CBC/PKCS5Padding";

    public static String encrypt(String password, String message) {
        try {
            // Generate salt
            byte[] salt = new byte[SALT_SIZE];
            new SecureRandom().nextBytes(salt);

            // Derive key
            KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_SIZE * 8);
            SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_DERIVATION_ALGORITHM);
            SecretKey secretKey = factory.generateSecret(spec);
            byte[] keyBytes = secretKey.getEncoded();
            SecretKeySpec keySpec = new SecretKeySpec(keyBytes, KEY_SPEC_ALGORITHM);

            // Generate IV
            byte[] iv = new byte[IV_SIZE];
            new SecureRandom().nextBytes(iv);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);

            // Encrypt the message
            Cipher cipher = Cipher.getInstance(CIPHER_TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec);
            byte[] encryptedBytes = cipher.doFinal(message.getBytes(StandardCharsets.UTF_8));

            // Concatenate salt + IV + encrypted message
            byte[] result = new byte[salt.length + iv.length + encryptedBytes.length];
            System.arraycopy(salt, 0, result, 0, salt.length);
            System.arraycopy(iv, 0, result, salt.length, iv.length);
            System.arraycopy(encryptedBytes, 0, result, salt.length + iv.length, encryptedBytes.length);

            // Encode to Base64
            return Base64.getEncoder().encodeToString(result);

        } catch (Exception e) {
            // In a real application, handle this exception more gracefully
            // For Karate, throwing a RuntimeException might be acceptable to fail the test
            throw new RuntimeException("Encryption failed: " + e.getMessage(), e);
        }
    }

    // Optional: Add a main method for quick testing outside Karate
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java api.utilities.EncryptionUtils 'P@$$w0rd' <message>");
            return;
        }
        String password = args[0];
        String message = args[1];
        String encrypted = encrypt(password, message);
        System.out.println("Password: " + password);
        System.out.println("Message: " + message);
        System.out.println("Encrypted (Base64): " + encrypted);
    }
}

