function fn() {
  var configData = karate.read("classpath:config.json");
  karate.configure('connectTimeout', 6000000);
  karate.configure('readTimeout', 6000000);

  var env = karate.env; // get system property 'karate.env'
  // karate.log('karate.env system property was:', env);
  // if (!env) {
  //   env = 'dev';
  // }
  // var config = {
  //   env: env,
  //   myVarName: 'someValue',
  // }
  if (env == 'develop') {
    // customize
    // e.g. config.foo = 'bar';
    b2cCheckerUsername = configData.B2C_CHECKER_USERNAME_DEV,
    b2cCheckerPassword = configData.B2C_CHECKER_PASSWORD_DEV,
    b2cMakerUsername = configData.B2C_MAKER_USERNAME_DEV,
    b2cMakerPassword = configData.B2C_MAKER_PASSWORD_DEV,
    b2cTokenUrl = configData.B2C_TOKEN_URL_DEV,
    b2cPostUrl = configData.B2C_CHECKER_POST_URL
    // encodedPassword = java.util.Base64.getEncoder().encodeToString('P@$$W0rd'.getBytes())
  } else if (env == 'e2e') {
    // customize
    b2cUsername = configData.B2C_USERNAME_RELEASE,
    b2cPassword = configData.B2C_PASSWORD_RELEASE,
    b2cTokenUrl = configData.B2C_TOKEN_URL_RELEASE,
    b2cPostUrl = configData.B2C_CHECKER_POST_URL
  }

 var config = {
    baseUrl: configData.BASE_URL,
    b2cTokenUrl: configData.B2C_TOKEN_URL_DEV,
    tokenUrl: configData.B2C_TOKEN_URL,
    b2cPostUrl:configData.B2C_CHECKER_POST_URL
 }

  return config;
}