export const config = {
  baseUrl: 'https://192.168.6.172/security/login',
  baseUrlDev: 'https://192.168.6.172/security/login',
  bulkUploadUrl: 'https://192.168.0.36:8950/security/login',
  username: 'Admin1',
  password: 'P@$$w0rd',
  makeruser:'Admin2',
  makerPassword:'P@$$w0rd',
  checkeruser:'Admin2',
  checkerPassword:'P@$$w0rd'
};