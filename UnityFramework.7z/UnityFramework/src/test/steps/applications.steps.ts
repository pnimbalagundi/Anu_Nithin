import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { login } from '../../utils/loginUtils';
import { logger } from '../../utils/logger';
import { app_selectors } from '../pageobjects/applications.page';
import { config } from '../config/config';
import { login_selectors } from '../pageobjects/login.page';

setDefaultTimeout(80000);
// const logger = winston.createLogger({ /* ... */ }); // Outside class, as a module constant

 Given('Checker User navigates to application', async function (this: CustomWorld) {
//  Given('login to the application', async function (this: CustomWorld,userName:string,password:string) {
  logger.info('Checker Starting login process');
  // await login(this.page!);
  await this.page!.goto(config.baseUrl, {timeout: 80000, waitUntil: 'load',});
  await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 80000 });
  await this.page!.locator(login_selectors.loginUsernameEntry).fill(config.username);
  await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
  await this.page!.locator(login_selectors.loginPasswordEntry).fill(config.password);
  await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
  await expect(this.page!.locator('#SvgjsPath1021')).toBeVisible({ timeout: 100000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('Checker Login step completed');
});

Given('Maker User navigates to application', async function (this: CustomWorld) {
    logger.info('Maker Starting login process');
    await this.page!.goto(config.baseUrl, {timeout: 100000, waitUntil: 'load',});
    await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 100000 });
    await this.page!.locator(login_selectors.loginUsernameEntry).fill(config.makeruser);
    await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
    await this.page!.locator(login_selectors.loginPasswordEntry).fill(config.password);
    await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
    await expect(this.page!.locator('#SvgjsPath1021')).toBeVisible({ timeout: 80000 });   
    await this.page!.waitForLoadState("networkidle");
    logger.info('Maker Login step completed');
  });

  
Given('Verify that Employer Master Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('TC_WPS_SAL_01 - Verify that Employer Master Page is accessable Successfully started');
  // await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  // await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.maintenanceLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.wpsEmployerMaster).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.createEmployeLink)).toContainText('Employer Create', { timeout: 80000 });
  await expect(this.page!.locator(app_selectors.employerMasterHeader)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerMasterHeader).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_01 - Verify that Employer Master Page Ended Successfully');
  return true;
});

Given('Verify that Salary Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('Verify that Salary Page is accessable Successfully started');
  // await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  // await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.uploadSalarySideMenu).click({ timeout: 80000 });
   await expect(this.page!.locator(app_selectors.salaryHeader)).toContainText('Salary File Upload');
  await this.page!.waitForLoadState("networkidle");
  logger.info('Verify that Salary Page Ended Successfully');
  return true;
});

Given('Verify that Salary Reports Salary Page is displayed Successfully {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_WPS_SAL_041_Verify that Salary Reports Salary 360 Page started');
  // await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  // await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsReportsLink).first().click({ timeout: 80000 });
  await this.page!.getByText('Salary', { exact: true }).nth(1).click({ timeout: 80000 });
  await this.page!.getByRole('link', { name: 'Salary' }).click({ timeout: 80000 });
    // await this.page!.locator(app_selectors.wpsSalaryLink).click();
  // await this.page!.locator(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  // await this.page!.locator(app_selectors.salary360Menu).first().click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.salary360Header)).toContainText('Salary 360 Report');
  await expect(this.page!.getByRole('textbox', { name: 'Input File Name' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('textbox', { name: 'Input File Name' }).click({ timeout: 80000 });
  await this.page!.getByRole('textbox', { name: 'Input File Name' }).fill(dataFile);
  await this.page!.getByRole('button', { name: 'Search' }).click({ timeout: 80000 });
  await expect(this.page!.locator('.dxrd-report-preview-content > div:nth-child(2)')).toBeVisible({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_041_Verify that Salary Reports Salary 360 Page Ended Successfully');
  return true;
});

Given('Navigate to Upload Salary Page', async function (this: CustomWorld) {
  logger.info('Verify that Salary Page is accessable Successfully started');
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.uploadSalarySideMenu).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.salaryHeader)).toContainText('Salary File Upload');
  await this.page!.waitForLoadState("networkidle");
  logger.info('Verify that Salary Page Ended Successfully');
  return true;
});

Given('Navigate to Maintenance Page', async function (this: CustomWorld) {
  logger.info('Verify that Maintenance Page is accessable Successfully started');
  await this.page!.getByText(app_selectors.maintenanceLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.wpsEmployerMaster).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('Verify that Salary Page Ended Successfully');
  return true;
});


Given('Navigate to Review Salary Page', async function (this: CustomWorld) {
  logger.info('Verify that Review Salary Page is accessable Successfully started');
  // await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  // await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.reviewSalarySideMenu).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.reviewFileHeader)).toContainText('Review file');
  await this.page!.waitForLoadState("networkidle");
  logger.info('Verify that Review Salary Page Ended Successfully');
  return true;
});

When('User Accepts Salary from Review Salary Page {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('User Accepts Salary from Review Salary Successfully started');
  await this.page!.locator('//*[@id="clientData"]/tbody/tr[1]/td[1]').click({ timeout: 80000 });
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await expect(this.page!.getByRole('button', { name: 'Accept' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('button', { name: 'Accept' }).click({ timeout: 80000 });
  await expect(this.page!.getByRole('textbox', { name: 'Posting Status' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('button', { name: 'Ok' }).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('User Accepts Salary from Review Salary Page Ended Successfully');
  return true;
});

Given('Verify that Review Salary Page is displayed Successfully', async function (this: CustomWorld) {
  logger.info('Verify that Review Salary Page is accessable Successfully started');
  // await this.page!.getByText(app_selectors.applicationLink).first().click({ timeout: 80000 });
  // await this.page!.getByText(app_selectors.wpsLink).click({ timeout: 80000 });
  await this.page!.getByText(app_selectors.wpsSalaryLink).first().click({ timeout: 80000 });
  await this.page!.locator(app_selectors.reviewSalarySideMenu).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.reviewFileHeader)).toContainText('Review file');
  await this.page!.waitForLoadState("networkidle");
  logger.info('Verify that Review Salary Page Ended Successfully');
  return true;
});

When('Checker user creates Employer with valid data {string} {string} {string}', async function (this: CustomWorld,employerId:string, empName:string ,accountNo:string) {
  logger.info('TC_WPS_SAL_02 - Verify User enters Employer Data Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(empName);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo);
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerPhNoData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerFaxNoData).click();
  await this.page!.locator(app_selectors.employerFaxNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerPOBoxData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPOBoxData).fill('1');
  await this.page!.locator(app_selectors.employerAdd1Data).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAdd1Data).fill(employerId);
  await this.page!.getByText('Economic Activity None').click({ timeout: 80000 });
  await this.page!.locator(app_selectors.EmirateCodeTextBox).selectOption('1');  
  await this.page!.locator(app_selectors.Activity).selectOption('2');
  await this.page!.locator(app_selectors.contactPerson).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.contactPerson).fill('Tester');
  await this.page!.locator(app_selectors.ContactPersonNbr).click();
  await this.page!.locator(app_selectors.ContactPersonNbr).fill('1234567890');
  await this.page!.locator(app_selectors.FixedCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.FixedCharge).fill('10');
  await this.page!.locator(app_selectors.VariableCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.VariableCharge).fill('1');
  await this.page!.locator(app_selectors.ChkPost).click({ timeout: 80000 });
  logger.info('TC_WPS_SAL_05 - Verify added account number associated with employer Id on Employ Master started');
  await expect(this.page!.locator(app_selectors.accountNumberBody)).toContainText(employerId);
  logger.info('TC_WPS_SAL_05 - Verify added account number associated with employer Id on Employ Master ended');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_02 - Verify that user can be able to add New Employer Master record Ended Successfully');
  return true;
});

When('Checker user edits Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.editLink).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData1).fill('1234567890');
  await this.page!.locator(app_selectors.employerAdd2Data).fill('address2');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data Ended Successfully');
  return true;
});

When('User verify Pagination Functionality on Employer Master Page', async function (this: CustomWorld) {
  logger.info('TC_WPS_SAL_06 - User verify Pagination Functionality on Employer Master Page started Successfully');
  await this.page!.locator(app_selectors.employerMasterHeader).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toBeVisible({timeout:80000});
  logger.info('validate page 1 started');
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toContainText('Showing 1 to 10 of ');
  await expect(this.page!.locator(app_selectors.paginationPage)).toBeVisible({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.paginationPage)).toContainText('1');
  logger.info('validate page 1 ended');
  await this.page!.locator(app_selectors.secondPageLink).click({ timeout: 80000 });
  logger.info('validate page 2 started');
  await expect(this.page!.locator(app_selectors.clientDataInfo)).toContainText('Showing 11 to 20 of ');
  await expect(this.page!.locator(app_selectors.paginationPage)).toContainText('2');
  logger.info('validate page 2 ended');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_06 - User verify Pagination Functionality on Employer Master Page Ended Successfully');
  return true;
});


When('Checker user deletes Employer with valid data {string}', async function (this: CustomWorld,employerId:string,) {
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to delete the employer master data started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.editLink).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.deleteCheckbox)).toBeVisible();
  await this.page!.locator(app_selectors.deleteCheckbox).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible();
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer deleted successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_07 - Verify that user can be able to delete the employer master data Ended Successfully');
  return true;
});

When('Checker user deletes default account from Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_26 - Verify that user can be able to delete default account from the employer master data started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.editLink).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.deleteDefaultAccount)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.deleteDefaultAccount).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_26 - Verify that user can be able to delete default account from the employer master data Ended Successfully');
  return true;
});

When('User verify EmpId, Name and Iban on Employer Master Page {string} {string} {string}', async function (this: CustomWorld, employerId:string, employerName:string, employerIBan:string,) {
  logger.info('TC_08_09_10_Checker User verify EmpId, Name and Iban on Employer Master Page started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  logger.info('User verify EmpId started Successfully');
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify EmpId ended Successfully');
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  logger.info('User verify Emp Name started Successfully');
  await this.page!.locator(app_selectors.employerNameSearchBox).fill(employerName);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerName);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify Emp Name ended Successfully'); 
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  logger.info('User verify Emp IBan started Successfully');
  await this.page!.locator(app_selectors.employerIBanSearchBox).fill(employerIBan);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerIBan);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  logger.info('User verify Emp IBan ended Successfully');  
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_08_09_10_Checker User verify EmpId, Name and Iban on Employer Master Page Ended Successfully');
  return true;
});


When('Checker user reedits Employer with valid data {string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_11 - Verify edit case for already sent employer approval case on Employer Master page started Successfully');
  await expect(this.page!.locator(app_selectors.employerIDSearchBox)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.clearFilterButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDSearchBox).fill(employerId);
  await this.page!.locator(app_selectors.searchButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.assertText)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.assertStatus)).toContainText('Active');
  await expect(this.page!.locator(app_selectors.editLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.editLink).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData1).fill('1234567890');
  await this.page!.locator(app_selectors.employerAdd2Data).fill('address2');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Transaction already in workflow.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_04 - Verify that user can be able to edit the employer master data Ended Successfully');
  return true;
});

When('User uploads salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_WPS_SAL_13 - Verify User upload salary file started Successfully');
  const fileInput = await this.page!.locator(app_selectors.fileInput);
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('button', { name: 'Go' }).click({ timeout: 80000 });
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
  await this.page!.locator(app_selectors.fileSubmitButton).click({timeout:80000});
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText(app_selectors.validateUploadMessage);
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_13 - Verify User upload salary file Ended Successfully');
  return true;
  });

  When('User uploads salary file when employer is Inactive {string}', async function (this: CustomWorld, dataFile:string) {
    logger.info('TC_WPS_SAL_22 - Verify User upload salary file started Successfully');
    const fileInput = await this.page!.locator(app_selectors.fileInput);
    const filePath = dataFile;
    await fileInput.setInputFiles(filePath);
    await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible({ timeout: 80000 });
    await this.page!.getByRole('button', { name: 'Go' }).click({ timeout: 80000 });
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.locator(app_selectors.fileSubmitButton).click({timeout:80000});
    await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText(app_selectors.validateInactiveMessage);
    await this.page!.waitForLoadState("networkidle");
    logger.info('TC_WPS_SAL_22 - Verify User upload salary file Ended Successfully');
    return true;
    });

When('Checker user creates Employer with valid multiple account data {string}{string}{string}', async function (this: CustomWorld,employerId:string) {
  logger.info('TC_WPS_SAL_17 - Verify User creates Employer with valid multiple account data Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId);
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'1');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'2');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'3');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerId+'4');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerPhNoData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerFaxNoData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerFaxNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerPOBoxData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPOBoxData).fill('1');
  await this.page!.locator(app_selectors.employerAdd1Data).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAdd1Data).fill(employerId);
  await this.page!.getByText('Economic Activity None').click({ timeout: 80000 });
  await this.page!.locator(app_selectors.EmirateCodeTextBox).selectOption('1');  
  await this.page!.locator(app_selectors.Activity).selectOption('2');
  await this.page!.locator(app_selectors.contactPerson).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.contactPerson).fill('Tester');
  await this.page!.locator(app_selectors.ContactPersonNbr).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.ContactPersonNbr).fill('1234567890');
  await this.page!.locator(app_selectors.FixedCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.FixedCharge).fill('10');
  await this.page!.locator(app_selectors.VariableCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.VariableCharge).fill('1');
  await this.page!.locator(app_selectors.ChkPost).click({ timeout: 80000 });
  logger.info('TC_WPS_SAL_23 - Verify that one account should be default account in Employer Master started');
  await expect(this.page!.locator(app_selectors.accountNumberBody)).toContainText(employerId);
  logger.info('TC_WPS_SAL_23 - Verify that one account should be default account in Employer Master ended');
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Employer records saved successfully.', { timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_17 - Verify user creates Employer with valid multiple account data Ended Successfully');
  return true;
});


When('Checker user creates Employer with six account data {string}{string}{string}', async function (this: CustomWorld,employerId:string, empName:string ,accountNo:string) {
  logger.info('TC_WPS_SAL_17 - Verify User creates Employer with valid multiple account data Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(empName);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo);
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo+'1');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo+'2');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo+'3');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo+'4');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(accountNo+'5');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('You cannot add more than 5 accounts.', { timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_17 - Verify user creates Employer with valid multiple account data Ended Successfully');
  return true;
});


When('User verifies Emirates and Activity field dropdown values', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_20_21 - Verify User Emirates and Activity data started Successfully');
await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
await expect(this.page!.locator(app_selectors.validateEmirates)).toBeVisible();
await expect(this.page!.locator(app_selectors.validateEmirates)).toContainText('--Select-- Dubai Sharjah Abudhabi Fujairah Ras Al Khamah Umm Al Quwain Ajman');
await expect(this.page!.locator(app_selectors.validateActivity)).toContainText('None Banking Construction Retail Trading');
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_20_21 - Verify user Emirates and Activity data Ended Successfully');
return true;
});

When('Checker user creates Employer with valid multiple account Status No {string}', async function (this: CustomWorld,employerId:string, employerName:string, employerIBan:string,) {
  logger.info('TC_WPS_SAL_22 - Verify User creates Employer with valid multiple account data with Status No Successfully started');
  await expect(this.page!.locator(app_selectors.createEmployerLink)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.createEmployerLink).dblclick({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerIDTextBox).fill(employerId);
  await this.page!.locator(app_selectors.employerIDTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerNameTextBox).fill(employerName);
  await this.page!.locator(app_selectors.employerNameTextBox).press('Tab');
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerIBan);
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerIBan+'1');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerIBan+'2');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerIBan+'3');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAcctNbrTextBox).fill(employerIBan+'4');
  await this.page!.locator(app_selectors.addButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerTrdLicTextBox).fill(employerId);
  await expect(this.page!.locator(app_selectors.statusNoRadioButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.statusNoRadioButton).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPhNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerFaxNoData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerFaxNoData).fill('1234567890');
  await this.page!.locator(app_selectors.employerPOBoxData).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerPOBoxData).fill('1');
  await this.page!.locator(app_selectors.employerAdd1Data).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.employerAdd1Data).fill(employerId);
  await this.page!.getByText('Economic Activity None').click();
  await this.page!.locator(app_selectors.EmirateCodeTextBox).selectOption('1');  
  await this.page!.locator(app_selectors.Activity).selectOption('2');
  await this.page!.locator(app_selectors.contactPerson).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.contactPerson).fill('Tester');
  await this.page!.locator(app_selectors.ContactPersonNbr).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.ContactPersonNbr).fill('1234567890');
  await this.page!.locator(app_selectors.FixedCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.FixedCharge).fill('10');
  await this.page!.locator(app_selectors.VariableCharge).click({ timeout: 80000 });
  await this.page!.locator(app_selectors.VariableCharge).fill('1');
  await this.page!.locator(app_selectors.ChkPost).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.accountNumberBody)).toContainText(employerId);
  await expect(this.page!.locator(app_selectors.saveButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(app_selectors.saveButton).click({ timeout: 80000 });
  await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('The employer account is inactive');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_WPS_SAL_22 - Verify user creates Employer with valid multiple account data with Status No Ended Successfully');
  return true;
});


  When('User uploads error salary file {string}', async function (this: CustomWorld, dataFile:string) {
    logger.info('TC_WPS_SAL_29 - Verify User upload error salary file started Successfully');
    const fileInput = await this.page!.locator(app_selectors.fileInput);
    const filePath = dataFile;
    await fileInput.setInputFiles(filePath);
    await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible({ timeout: 80000 });
    await this.page!.getByRole('button', { name: 'Go' }).click({ timeout: 80000 });
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
    await expect(this.page!.locator(app_selectors.validateErrorTitle)).toBeVisible({ timeout: 80000 });
    await expect(this.page!.locator(app_selectors.validateErrorTitle)).toContainText('Error');
    await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('The file format you uploaded is not supported.');
    await this.page!.waitForLoadState("networkidle");
    logger.info('TC_WPS_SAL_29 - Verify User upload error salary file Ended Successfully');
    return true;
    });
    
    When('User tries to change uploaded salary file {string}', async function (this: CustomWorld, dataFile:string) {
      logger.info('TC_WPS_SAL_31 - Verify User changes uploaded salary file started Successfully');
      await expect(await this.page!.locator(app_selectors.fileInput)).toBeVisible({ timeout: 80000 });
      const fileInput = await this.page!.locator(app_selectors.fileInput);
      const filePath = dataFile;
      await fileInput.setInputFiles(filePath);
      await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible({ timeout: 80000 });
      await this.page!.getByRole('button', { name: 'Go' }).click({ timeout: 80000 });
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
      await this.page!.locator(app_selectors.changeButton).click({ timeout: 80000 });
      await expect(this.page!.locator(app_selectors.changeButton)).toBeVisible({ timeout: 80000 });
      // await this.page!.locator(app_selectors.changeButton).click({ timeout: 80000 });
      // await this.page!.goto('https://192.168.6.172/salary/uploadsiffile');
      // await this.page!.getByRole('link', { name: 'Change' }).click({ timeout: 80000 });
      // await expect(this.page!.locator(app_selectors.validateErrorTitle)).toBeVisible({ timeout: 80000 });
      await expect(this.page!.locator(app_selectors.validateErrorMessage)).toContainText('Salary file deleted successfully.', { timeout: 80000 });
      await this.page!.waitForLoadState("networkidle");
      logger.info('TC_WPS_SAL_31 - Verify User changes uploaded salary file Ended Successfully');
      return true;
      });

      When('User tries to cancel uploaded salary file {string}', async function (this: CustomWorld, dataFile:string) {
        logger.info('TC_WPS_SAL_32 - Verify User cancels uploaded salary file started Successfully');
        const fileInput = await this.page!.locator(app_selectors.fileInput);
        const filePath = dataFile;
        await fileInput.setInputFiles(filePath);
        await expect(this.page!.getByRole('button', { name: 'Go' })).toBeVisible({ timeout: 80000 });
        // await this.page!.getByRole('button', { name: 'Go' }).click({ timeout: 80000 });
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        await this.page!.getByText('Loading... Dashboard Welcome').press('ArrowDown');
        // await this.page!.locator(app_selectors.cancelButton).click({ timeout: 80000 });
        await this.page!.waitForLoadState("networkidle");
        logger.info('TC_WPS_SAL_32 - Verify User cancels uploaded salary file Ended Successfully');
        return true;
        });
  
        When('User Reviews uploaded salary file details', async function (this: CustomWorld) {
          logger.info('TC_WPS_SAL_40 - Verify that user can be able to view record details page by clicking reference number started Successfully');
          // await expect(this.page!.locator('(//td[@class="sorting_1"])[1]')).toBeVisible({ timeout: 80000 });
          // await this.page!.locator('(//td[@class="sorting_1"])[1]').first().click({ timeout: 80000 });
           await this.page!.locator('//a[normalize-space()="SIF2505220000016"]').click({ timeout: 80000 });
          //  await this.page!.locator('//tr[@class="odd"]').click({ timeout: 80000 });
          
            // const rows = this.page!.locator('//tr[@class="odd"]');
            // const firstRow = rows.first();
            // const refNo = await firstRow.locator('td:nth-child(1)').textContent(); 
            // console.log(`First Reference Number: ${refNo}`);
            // await firstRow.click(); 
          // await expect(this.page!.locator('#kt_app_content_container')).toContainText('Apr 2025');
          // await expect(this.page!.locator('#kt_app_content_container')).toContainText('165,000.00');
          // await expect(this.page!.locator('#kt_app_content_container')).toContainText('ALDARMAK008');
          // await expect(this.page!.locator('thead')).toContainText('00446229636376');
          // await expect(this.page!.locator('thead')).toContainText('002510101');
          // await expect(this.page!.locator('thead')).toContainText('AE760860953926551097745');
          await this.page!.waitForLoadState("networkidle");
          logger.info('TC_WPS_SAL_40 - Verify that user can be able to view record details page by clicking reference number Ended Successfully');
          return true;
          });
  
When('User Reviews Salary Accept Reject Cancel Buttons', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_42 - Verify that User Reviews Salary Accept Reject Cancel Buttons started Successfully');
await expect(this.page!.locator(app_selectors.cancelReviewSalaryButton)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.rejectButton)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.acceptButton)).toBeVisible({ timeout: 80000 });              
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_42 - Verify that User Reviews Salary Accept Reject Cancel Buttons Ended Successfully');
return true;
});

When('User Reviews Salary Accept Buttons', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_43 - Verify that the user can validate and use the Accept feature with ACK received scenario started Successfully');
await this.page!.locator(app_selectors.acceptButton).click({ timeout: 80000 });   
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_43 - Verify that the user can validate and use the Accept feature with ACK received scenario Ended Successfully');
return true;
});

When('User clicks Cancel Button from Reviews Salary page', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_46 - User clicks Cancel Button from Reviews Salary page started Successfully');
await expect(this.page!.locator(app_selectors.cancelReviewSalaryButton)).toBeVisible({ timeout: 80000 });
await this.page!.locator(app_selectors.cancelReviewSalaryButton).click({ timeout: 80000 });    
await expect(this.page!.locator('//a[normalize-space()="SIF2505220000016"]')).toBeVisible({ timeout: 80000 });        
// await expect(this.page!.locator('//tr[@class="odd"]')).toBeVisible({ timeout: 80000 });        
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_46 - User clicks Cancel Button from Reviews Salary page Ended Successfully');
return true;
});

When('User verifies Status from Reviews Salary page', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_47 - Verify that user can filter the record by changing the status started Successfully');
await expect(this.page!.locator(app_selectors.statusCode)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.statusCode)).toContainText('All Pending Posting Failed');
await expect(this.page!.locator(app_selectors.statusCode)).toHaveValue('A');
await this.page!.locator(app_selectors.statusCode).selectOption('P');
await this.page!.getByRole('button', { name: ' Search' }).click({ timeout: 80000 });
await this.page!.getByRole('button', { name: ' Search' }).press('ArrowRight');
await expect(this.page!.locator('tbody')).toContainText('Pending', { timeout: 80000 });
await this.page!.locator('#Status_code').selectOption('F');
await this.page!.getByRole('button', { name: ' Search' }).click({ timeout: 80000 });
await expect(this.page!.locator('tbody')).toContainText('Posting Failed', { timeout: 80000 });
await this.page!.getByRole('button', { name: ' Clear Filter' }).click({ timeout: 80000 });
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_47 - Verify that user can filter the record by changing the status Ended Successfully');
return true;
});

When('User verifies buttons Override Abandon and Retry for Posting Failed Scenario from Reviews Salary page', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_49 -Verify Override Abandon and Retry for Posting Failed started Successfully');
await this.page!.locator('#Status_code').selectOption('F');
await this.page!.getByRole('button', { name: ' Search' }).click({ timeout: 80000 });
await expect(this.page!.locator('tbody')).toContainText('Posting Failed', { timeout: 80000 });
await expect(this.page!.locator('//a[normalize-space()="AIF2504150000115"]')).toBeVisible({ timeout: 80000 });        
await this.page!.locator('//a[normalize-space()="AIF2504150000115"]').click({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.cancelReviewSalaryButton)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.retryButton)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.overrideButton)).toBeVisible({ timeout: 80000 });
await expect(this.page!.locator(app_selectors.abandonButton)).toBeVisible({ timeout: 80000 });
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_49 -Verify Override Abandon and Retry for Posting Failed Ended Successfully');
return true;
});


Then('User clicks Retry for Posting Failed Scenario from Reviews Salary page', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_50 -Verify clicks Retry for Posting Failed started Successfully');
await expect(this.page!.locator(app_selectors.retryButton)).toBeVisible({ timeout: 80000 });
await this.page!.locator(app_selectors.retryButton).click({ timeout: 80000 });
await expect(this.page!.locator('#okBtn')).toBeVisible({ timeout: 80000 }); 
await this.page!.locator('#okBtn').click({ timeout: 80000 });
await this.page!.waitForLoadState("networkidle");
logger.info('TC_WPS_SAL_50 -Verify User clicks Retry for Posting Failed Ended Successfully');
return true;
});

Then('Verify User logs out from application', async function (this: CustomWorld) {
logger.info('Logout -Verify User logout started Successfully');
await expect(this.page!.locator('[id="\\#kt_app_sidebar_menu"]')).toContainText('Sign Out');
await this.page!.getByRole('link', { name: ' Sign Out' }).click();
logger.info('Logout -Verify User logout Ended Successfully');
return true;
});

When('Maker User navigates to Workflow Pending page', async function (this: CustomWorld) {
logger.info('TC_WPS_SAL_02 -Verify Maker User navigates to Workflow Pending page started Successfully');
await this.page!.getByText('Workflow', { exact: true }).click();
await this.page!.getByRole('link', { name: ' Pending Queue' }).click();
logger.info('TC_WPS_SAL_02 -Verify Maker User navigates to Workflow Pending page Ended Successfully');
return true;
});
