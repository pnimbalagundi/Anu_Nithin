import { Given, When, Then, setDefaultTimeout } from '@cucumber/cucumber';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';
import { config } from '../config/config';
import { login_selectors } from '../pageobjects/login.page';
import { logger } from '../../utils/logger';
import { bulkUpload_selectors } from '../pageobjects/bulkUpload.page';

// setDefaultTimeout(80000);

// const logger = winston.createLogger({ /* ... */ }); // Outside class, as a module constant

Given('Checker User logs in to Bulk Upload application', async function (this: CustomWorld) {
  logger.info('Checker Starting login process');
  await this.page!.goto(config.bulkUploadUrl, {timeout: 80000, waitUntil: 'load',});
  await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 80000 });
  await this.page!.locator(login_selectors.loginUsernameEntry).fill(config.checkeruser);
  await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
  await this.page!.locator(login_selectors.loginPasswordEntry).fill(config.checkerPassword);
  await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
  // await expect(this.page!.locator('#SvgjsPath1124')).toBeVisible({ timeout: 100000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('Checker Login step completed');
});

Given('Maker User logs in to Bulk Upload application', async function (this: CustomWorld) {
  logger.info('Maker Starting login process');
  await this.page!.goto(config.bulkUploadUrl, {timeout: 80000, waitUntil: 'load',});
  await this.page!.locator(login_selectors.loginUsernameEntry).click({ timeout: 80000 });
  await this.page!.locator(login_selectors.loginUsernameEntry).fill(config.makeruser);
  await this.page!.locator(login_selectors.loginUsernameEntry).press('Tab');
  await this.page!.locator(login_selectors.loginPasswordEntry).fill(config.makerPassword);
  await this.page!.locator(login_selectors.loginButton).click({ timeout: 80000 });
  await expect(this.page!.locator('#SvgjsPath1021')).toBeVisible({ timeout: 100000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('Maker Login step completed');
});

Given('Maker User navigates to Bulk Upload application {string}', async function (this: CustomWorld, AccNo:string) {
  logger.info('Maker navigates to Bulk Upload Screen process');
  await this.page!.getByText(bulkUpload_selectors.bulkTransfersLink).click({ timeout: 80000 });
  await this.page!.getByText(bulkUpload_selectors.bulkUploadLink).click({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.iBanAccNo).click({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.iBanAccNo).fill(AccNo);
  await this.page!.getByRole('button', { name: 'Account Enquiry' }).click({ timeout: 80000 });
  await expect(this.page!.getByText('Account Enquiry Successfull.')).toBeVisible({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('Maker navigates to Bulk Upload Screen process ended');
});

When('Maker User uploads Bulk salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_Bulk_Upload_01 - Verify User uploads Bulk salary file started Successfully');
  await this.page!.locator(bulkUpload_selectors.templateDropdown).selectOption('3');
  const fileInput = await this.page!.getByRole('button', { name: 'Choose File' });
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.locator(bulkUpload_selectors.goButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.goButton).click({ timeout: 80000 });
  await expect(this.page!.getByText(bulkUpload_selectors.textValidate)).toBeVisible({ timeout: 80000 });
  await this.page!.getByText(bulkUpload_selectors.textValidate).click({ timeout: 80000 });
  await expect(this.page!.locator(bulkUpload_selectors.fullDetailsButton)).toContainText('Full Details',{ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Validation Status: activate' })).toBeVisible({ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Success' }).first()).toBeVisible({ timeout: 80000 });
  await expect(this.page!.getByRole('button', { name: ' Submit' })).toBeVisible({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_01 - Verify User uploads Bulk salary file Ended Successfully');
  return true;
  });


  When('Maker User tries to uploads already uploaded Bulk salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_Bulk_Upload_02 - Maker User tries to uploads already uploaded Bulk salary file started Successfully');
  await this.page!.locator(bulkUpload_selectors.templateDropdown).selectOption('3');
  const fileInput = await this.page!.getByRole('button', { name: 'Choose File' });
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.locator(bulkUpload_selectors.goButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.goButton).click({ timeout: 80000 });
  await expect(this.page!.locator('#toastr-container')).toContainText('File with same name already uploaded. Please verify before uploading.');
  await this.page!.getByRole('link', { name: ' Sign Out' }).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_02 - Maker User tries to uploads already uploaded Bulk salary file Ended Successfully');
  return true;
  });


  When('Maker User uploads processed records with new Bulk salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_Bulk_Upload_03 - Verify User uploads processed records with new Bulk salary file started Successfully');
  await this.page!.locator(bulkUpload_selectors.templateDropdown).selectOption('3');
  const fileInput = await this.page!.getByRole('button', { name: 'Choose File' });
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.locator(bulkUpload_selectors.goButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.goButton).click({ timeout: 80000 });
  await expect(this.page!.getByText(bulkUpload_selectors.textValidate)).toBeVisible({ timeout: 80000 });
  await this.page!.getByText(bulkUpload_selectors.textValidate).click({ timeout: 80000 });
  await expect(this.page!.locator(bulkUpload_selectors.fullDetailsButton)).toContainText('Full Details',{ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Validation Status: activate' })).toBeVisible({ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Failed' }).first()).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('row', { name: '1 1201' }).getByRole('link').click({ timeout: 80000 });
  await expect(this.page!.locator(bulkUpload_selectors.failedRecord)).toContainText('SendingInstRefIndividualTransaction already exists with file name Template_3_AlreadyUploadedError_Format_1 and value date: 26/05/2025.');
  await this.page!.getByRole('button', { name: 'Close' }).click({ timeout: 80000 });
  await this.page!.getByRole('link', { name: ' Sign Out' }).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_03 - Verify User uploads processed records with new Bulk salary file Ended Successfully');
  return true;
  });


  When('Maker User Downloads Full Details Bulk salary file {string}', async function (this: CustomWorld, dataFile:string) {
  logger.info('TC_Bulk_Upload_04 - Verify Maker User Downloads Full Details Bulk salary file started Successfully');
  await this.page!.locator(bulkUpload_selectors.templateDropdown).selectOption('3');
  const fileInput = await this.page!.getByRole('button', { name: 'Choose File' });
  const filePath = dataFile;
  await fileInput.setInputFiles(filePath);
  await expect(this.page!.locator(bulkUpload_selectors.goButton)).toBeVisible({ timeout: 80000 });
  await this.page!.locator(bulkUpload_selectors.goButton).click({ timeout: 80000 });
  await expect(this.page!.getByText(bulkUpload_selectors.textValidate)).toBeVisible({ timeout: 80000 });
  await this.page!.getByText(bulkUpload_selectors.textValidate).click({ timeout: 80000 });
  await expect(this.page!.locator(bulkUpload_selectors.fullDetailsButton)).toContainText('Full Details',{ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Validation Status: activate' })).toBeVisible({ timeout: 80000 });
  await expect(this.page!.getByRole('cell', { name: 'Success' }).first()).toBeVisible({ timeout: 80000 });
  const downloadPromise = this.page!.waitForEvent('download');
  await this.page!.locator(bulkUpload_selectors.fullDetailsButton).click({ timeout: 80000 });
  const download = await downloadPromise;
  await this.page!.on('download', (download: { path: () => Promise<any>; }) => download.path().then(console.log));
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_04 - Verify Maker User Downloads Full Details Bulk salary file Ended Successfully');
  return true;
  });


  When('Maker User Submits Bulk salary file and Submits Record', async function (this: CustomWorld) {
  logger.info('TC_Bulk_Upload_05 - Verify User submits Bulk salary file started Successfully');
  await expect(this.page!.getByRole('button', { name: ' Submit' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('button', { name: ' Submit' }).click({ timeout: 80000 });
  await expect(this.page!.getByText('Transaction Sent for Approval.')).toBeVisible({ timeout: 120000 });
  await this.page!.getByRole('link', { name: ' Sign Out' }).click({ timeout: 80000 });
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_05 - Verify User submits Bulk salary file Ended Successfully');
  return true;
  });

  When('Checker User navigates to Approval Page', async function (this: CustomWorld) {
  logger.info('TC_Bulk_Upload_05 - Verify Checker User navigates to Approval Page started Successfully');
  await expect(this.page!.getByRole('link', { name: 'Pending Queue' })).toBeVisible({ timeout: 80000 });
  await this.page!.getByRole('link', { name: 'Pending Queue' }).click({ timeout: 80000 });
  await expect(this.page!.locator('td').first()).toBeVisible({ timeout: 80000 });
  await expect(this.page!.locator('td:nth-child(6)').first()).toBeVisible({ timeout: 80000 });
  await expect(this.page!.locator('td:nth-child(7)').first()).toBeVisible({ timeout: 80000 });
  await this.page!.locator('td:nth-child(8)').first().click({ timeout: 80000 });
  await this.page!.locator('#kt_app_body').press('ArrowRight');
  await this.page!.locator('#kt_app_body').press('ArrowRight');
  await this.page!.locator('#kt_app_body').press('ArrowRight');
  await this.page!.locator('#kt_app_body').press('ArrowRight');
  await this.page!.locator('#kt_app_body').press('ArrowRight');
  await this.page!.locator("//td[@class='  center'][1] //a[@class='btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1'][1]").first().click({ timeout: 80000 });
  await expect(this.page!.locator('#toastr-container')).toContainText('Transaction locked.');
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_05 - Verify Checker User navigates to Approval Page Ended Successfully');
  return true;
  });


  When('Checker User Approves Bulk salary file and Submits Record', async function (this: CustomWorld) {
  logger.info('TC_Bulk_Upload_05 - Verify Checker User Approves Bulk salary file started Successfully');
  await expect(this.page!.locator('#WorkflowData_Approve')).toContainText('Approve',{ timeout: 80000 });
  await this.page!.getByRole('button', { name: ' Approve' }).click({ timeout: 80000 });
  await expect(await this.page!.locator('#wcp i').nth(2).getByRole('img').first()).not.toBeVisible({timeout: 160000});
  await expect(this.page!.getByText('Error', { exact: true })).toBeVisible({timeout: 160000});
  // await expect(this.page!.getByText('Success', { exact: true })).toBeVisible({timeout: 160000});
  await this.page!.waitForLoadState("networkidle");
  logger.info('TC_Bulk_Upload_05 - Verify Checker User Approves Bulk salary file Ended Successfully');
  return true;
  });