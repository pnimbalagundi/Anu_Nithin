import { Given, When, Then } from '@cucumber/cucumber';
import { Browser, Page, chromium } from '@playwright/test';
import * as fs from 'fs';
import PDFParser from 'pdf2json';
import { expect } from '@playwright/test';
import { CustomWorld } from '../support/world';

// let browser: Browser;
// let page: Page;

// Helper function to parse PDF and extract text
async function getPDFText(pdfPath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const pdfParser = new PDFParser();
    pdfParser.on('pdfParser_dataError', (errData) => reject(errData.parserError));
    pdfParser.on('pdfParser_dataReady', (pdfData) => {
      const textContent = pdfParser.getRawTextContent();
      resolve(textContent);
    });
    pdfParser.loadPDF(pdfPath);
  });
}

// Given('the user navigates to the application', async function () {
//   browser = await chromium.launch({ headless: false }); // Set headless: true for CI
//   page = await browser.newPage();
//   await page.goto('https://your-application-url.com'); // Replace with your app URL
// });

When('the user clicks the button to open or download the PDF', async function () {
  // Assuming the PDF is downloadable via a button or link
  const [download] = await Promise.all([
    this.page!.waitForEvent('download'), // Wait for the download event
    this.page!.click('#pdfDownloadButton'), // Replace with the actual selector
  ]);

  // Save the downloaded PDF to a temporary file
  const pdfPath = './temp-downloaded.pdf';
  await download.saveAs(pdfPath);
  this.pdfPath = pdfPath; // Store the path in the world object for later use
});

Then('the PDF should contain the expected text {string}', async function (expectedText: string) {
  const pdfPath = this.pdfPath; // Retrieve the path from the world object
  const pdfText = await getPDFText(pdfPath);

  // Verify the text
  expect(pdfText).toContain(expectedText);

  // Cleanup: Remove the temporary file and close the browser
  fs.unlinkSync(pdfPath);
//   await browser.close();
});


//Alternative
When('the user views the embedded PDF', async function () {
  const pdfUrl = await this.page!.locator('iframe').getAttribute('src'); // Adjust selector
  const response = await this.page!.request.get(pdfUrl);
  const pdfBuffer = await response.body();
  const pdfPath = './temp-embedded.pdf';
  fs.writeFileSync(pdfPath, pdfBuffer);
  this.pdfPath = pdfPath;
});