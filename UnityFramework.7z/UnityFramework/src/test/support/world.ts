import { setWorldConstructor, World } from '@cucumber/cucumber';
import { Browser, Page, BrowserContext, chromium } from '@playwright/test';

export class CustomWorld extends World {
  browser?: Browser;
  context?: BrowserContext;
  page?: Page;
  // [x: string]: any;
  // private base: Base;
  constructor(options: any) {
    super(options);
  }

  async init() {
    this.browser = await chromium.launch({ headless: true });
    this.context = await this.browser.newContext();
    this.page = await this.context.newPage();
}

async close() {
    await this.page!.close();
    await this.context!.close();
    await this.browser!.close();
}
}

  //   async getPage() {
  //   return await this.base.setup();
  // }

  // async captureScreenshot(scenarioName: string) {
  //   await this.base.captureScreenshotOnFailure(scenarioName);
  // }

  // async cleanup() {
  //   await this.base.teardown();
  // }
// }
setWorldConstructor(CustomWorld);

// import { setWorldConstructor } from '@cucumber/cucumber';
// import { Base } from '../../utils/base';
//
// export class CustomWorld {
//   [x: string]: any;
//   private base: Base;
//
//   constructor() {
//     this.base = new Base();
//   }
//
//   async getPage() {
//     return await this.base.setup();
//   }
//
//   async captureScreenshot(scenarioName: string) {
//     await this.base.captureScreenshotOnFailure(scenarioName);
//   }
//
//   async cleanup() {
//     await this.base.teardown();
//   }
// }
//
// setWorldConstructor(CustomWorld);