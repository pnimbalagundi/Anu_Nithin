export const bulkUpload_selectors = {
    bulkTransfersLink:'Bulk Transfers',
    bulkUploadLink:'Bulk Upload',
    iBanAccNo: "#DebtorIBANInput",
    templateDropdown: '#templatedtl',
    goButton: "#uploadButton",
    failedRecord:'#pFailureModalBodyContent',
    fullDetailsButton: '#btnDownloadFullDetails',
    submitButton:'#btnSubmit',
    workFlowLink:'Workflow', 
    pendingQueueLink:'Pending Queue',
    alertMessage:'#toastr-container',
    approveButton:'#WorkflowData_Approve',
    textValidate:'Clear Submit Please wait...'
};